import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../userentity/user';

@Injectable({
  providedIn: 'root'
})
export class  UserService{

  private baseUrl = 'http://localhost:8080/api';

  constructor(private http: HttpClient) { }

  createUser(user: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}` + `/create`, user);
  }

  getUserByUserName(userName: String): Observable<any>{
    return this.http.get(`${this.baseUrl}/username/${userName}`);
  }  
}
import { Component, OnInit, Input } from '@angular/core';
import { User } from '../userentity/user';
import { UserService } from '../userentity/user.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
  user_Name: String;

  constructor(private userservice: UserService) { }
  user: User=new User();
  users: User={
    firstName: '',
    lastName: '',
    userName: '',
    password: '',
  }
  
  ngOnInit() {
    this.resetForm();
    this.users.firstName;
    this.users.lastName;
    this.users.userName;
    this.users.password;    
    }

  newUser(): void {
    //this.user = new User();
  }

  resetForm(form? : NgForm)
  {
    if(form!=null)
    form.reset();
    this.user={
      firstName: '',
      lastName: '',
      userName: '',
      password: '',
    }
  }

  save() {
    this.userservice.createUser(this.user)
      .subscribe(data => console.log(data), error => console.log(error));
    this.user = new User();
  }
  checkUser(){
    this.userservice.getUserByUserName(this.user.userName)
      .subscribe(users => this.users = users);
      console.log(this.users);
    
    if(this.user.userName==this.users.userName)
    {
      alert("this user name is already exist");
    }
    else
    {
      alert(this.users.userName);
    }
  }

  onSubmit() {
    
    this.checkUser();
  }

}


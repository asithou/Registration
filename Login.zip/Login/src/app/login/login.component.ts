import { Component, OnInit } from '@angular/core';
import { User } from '../userentity/user';
import { NgForm } from '@angular/forms'; 

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor() { }

  user: User;

  ngOnInit() {
    this.resetForm();
  }

  resetForm(form? : NgForm)
  {
    if(form!=null)
    form.reset();
    this.user=
    {
    firstName: '',
    lastName: '',
    userName: '',
    password: '',
    }
  }

}
